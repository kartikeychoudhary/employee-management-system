export class Employee {
  id: number;
  password: string;
}
